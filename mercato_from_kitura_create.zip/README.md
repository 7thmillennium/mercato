Mercato


created using:
	kitura create
		-CRUD swagger SDK from /definition/mercato.json


Linking ./.build/x86_64-unknown-linux/debug/mercato
swift build command completed
generated: ./mercato.xcodeproj
generate .xcodeproj command completed
Next steps:

  Change directory to your app
    $ cd /home/looper/projects/LABORATORY/mercato

  Create a model in your app
    $ yo swiftserver:model

  Run your app
    $ .build/debug/mercato
