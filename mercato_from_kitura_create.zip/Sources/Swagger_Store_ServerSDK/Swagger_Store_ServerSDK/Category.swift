import Foundation

public class Category: Codable {
    public var id: Int64?
    public var name: String?
}
