import Foundation

public class Tag: Codable {
    public var id: Int64?
    public var name: String?
}
