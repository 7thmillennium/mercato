import Kitura
import CloudEnvironment

public func initializeCRUDResources(cloudEnv: CloudEnv, router: Router) throws {
}
